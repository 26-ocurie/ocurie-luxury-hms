-- Ocurie Luxury HMS - Database Schema

PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;

-- ── USERS (staff / login accounts) ─────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
    id          TEXT PRIMARY KEY,
    username    TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    name        TEXT NOT NULL,
    role        TEXT NOT NULL CHECK(role IN ('admin','manager','receptionist','housekeeper')),
    department  TEXT NOT NULL DEFAULT 'General',
    shift       TEXT NOT NULL DEFAULT 'Morning',
    phone       TEXT,
    email       TEXT,
    status      TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','inactive')),
    avatar_color TEXT DEFAULT '#C9A84C',
    created_at  TEXT DEFAULT (datetime('now')),
    updated_at  TEXT DEFAULT (datetime('now'))
);

-- ── ROOMS ───────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS rooms (
    id          TEXT PRIMARY KEY,
    number      TEXT UNIQUE NOT NULL,
    type        TEXT NOT NULL CHECK(type IN ('Economy','Standard','Deluxe','Suite')),
    floor       INTEGER NOT NULL DEFAULT 1,
    status      TEXT NOT NULL DEFAULT 'available'
                    CHECK(status IN ('available','occupied','cleaning','maintenance','reserved')),
    price_per_night REAL NOT NULL,
    capacity    INTEGER NOT NULL DEFAULT 2,
    amenities   TEXT DEFAULT '[]',       -- JSON array
    description TEXT,
    notes       TEXT,
    created_at  TEXT DEFAULT (datetime('now')),
    updated_at  TEXT DEFAULT (datetime('now'))
);

-- ── GUESTS ──────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS guests (
    id          TEXT PRIMARY KEY,
    first_name  TEXT NOT NULL,
    last_name   TEXT NOT NULL,
    email       TEXT,
    phone       TEXT,
    nationality TEXT,
    id_type     TEXT DEFAULT 'Passport',
    id_number   TEXT,
    vip         INTEGER DEFAULT 0,
    notes       TEXT,
    total_stays INTEGER DEFAULT 0,
    last_stay   TEXT,
    created_at  TEXT DEFAULT (datetime('now')),
    updated_at  TEXT DEFAULT (datetime('now'))
);

-- ── RESERVATIONS ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS reservations (
    id          TEXT PRIMARY KEY,
    res_number  TEXT UNIQUE NOT NULL,
    guest_id    TEXT NOT NULL REFERENCES guests(id),
    room_id     TEXT NOT NULL REFERENCES rooms(id),
    check_in    TEXT NOT NULL,
    check_out   TEXT NOT NULL,
    nights      INTEGER NOT NULL,
    adults      INTEGER DEFAULT 2,
    children    INTEGER DEFAULT 0,
    total_amount REAL NOT NULL,
    paid_amount REAL DEFAULT 0,
    status      TEXT NOT NULL DEFAULT 'confirmed'
                    CHECK(status IN ('confirmed','checked_in','checked_out','cancelled','no_show')),
    payment_method TEXT DEFAULT 'Credit Card',
    special_requests TEXT,
    notes       TEXT,
    created_by  TEXT REFERENCES users(id),
    created_at  TEXT DEFAULT (datetime('now')),
    updated_at  TEXT DEFAULT (datetime('now'))
);

-- ── INVOICES ────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS invoices (
    id          TEXT PRIMARY KEY,
    inv_number  TEXT UNIQUE NOT NULL,
    reservation_id TEXT REFERENCES reservations(id),
    guest_id    TEXT REFERENCES guests(id),
    room_charges REAL DEFAULT 0,
    extra_charges REAL DEFAULT 0,
    extras_detail TEXT DEFAULT '[]',    -- JSON
    total_amount REAL NOT NULL,
    paid_amount REAL DEFAULT 0,
    status      TEXT DEFAULT 'pending' CHECK(status IN ('pending','paid','partial','voided')),
    issued_at   TEXT DEFAULT (datetime('now')),
    paid_at     TEXT,
    notes       TEXT
);

-- ── HOUSEKEEPING TASKS ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS housekeeping (
    id          TEXT PRIMARY KEY,
    room_id     TEXT NOT NULL REFERENCES rooms(id),
    assigned_to TEXT REFERENCES users(id),
    priority    TEXT DEFAULT 'Medium' CHECK(priority IN ('High','Medium','Low')),
    task_type   TEXT DEFAULT 'cleaning',
    notes       TEXT,
    status      TEXT DEFAULT 'pending' CHECK(status IN ('pending','in_progress','completed','inspected')),
    created_at  TEXT DEFAULT (datetime('now')),
    updated_at  TEXT DEFAULT (datetime('now')),
    completed_at TEXT
);

-- ── AUDIT LOG ───────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS audit_log (
    id          TEXT PRIMARY KEY,
    user_id     TEXT REFERENCES users(id),
    action      TEXT NOT NULL,
    entity_type TEXT,
    entity_id   TEXT,
    details     TEXT,
    ip_address  TEXT,
    created_at  TEXT DEFAULT (datetime('now'))
);

-- ── INDEXES ─────────────────────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_reservations_guest   ON reservations(guest_id);
CREATE INDEX IF NOT EXISTS idx_reservations_room    ON reservations(room_id);
CREATE INDEX IF NOT EXISTS idx_reservations_status  ON reservations(status);
CREATE INDEX IF NOT EXISTS idx_reservations_checkin ON reservations(check_in);
CREATE INDEX IF NOT EXISTS idx_housekeeping_room    ON housekeeping(room_id);
CREATE INDEX IF NOT EXISTS idx_housekeeping_status  ON housekeeping(status);
CREATE INDEX IF NOT EXISTS idx_invoices_reservation ON invoices(reservation_id);
CREATE INDEX IF NOT EXISTS idx_audit_user           ON audit_log(user_id);
